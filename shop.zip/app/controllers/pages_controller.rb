class PagesController < Spree::BaseController

  layout 'spree_application'
  def contact
  end

  def legal_advice
  end
  
  def fake_home
  end

end
