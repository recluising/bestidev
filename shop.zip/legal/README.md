Legal
=====

Introduction goes here.


Example
=======

Example goes here.


Copyright (c) 2010 [name of extension creator], released under the New BSD License
