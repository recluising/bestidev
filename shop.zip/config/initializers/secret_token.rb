# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Onlineshop::Application.config.secret_token = '4b647fd206ebd57087ed37a009f3f9553225ddff0a17eec6f9f0100f4535953c0e602e2965de981dfce2fccace9eb5a28b1db0352d05f666ab58fc1f9b2c3d48'
